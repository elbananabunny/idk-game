#!/bin/bash

java -jar idk.jar