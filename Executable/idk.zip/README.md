This is the folder that holds only what is needed to run the game.

If you are on Windows, simply double click on the idk.bat file.

If you are on any other operating system (Unix, Linux, Mac, etc.), click on the idk.sh file instead.